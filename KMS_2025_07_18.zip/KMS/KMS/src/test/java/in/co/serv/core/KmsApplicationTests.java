package in.co.serv.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
